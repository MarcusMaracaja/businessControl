import 'package:flutter/material.dart';
import '../models/cliente.dart';
import '../controllers/cliente_controller.dart';
import 'cliente_form_screen.dart';

class ClienteListScreen extends StatefulWidget {
  const ClienteListScreen({super.key});

  @override
  State<ClienteListScreen> createState() => _ClienteListScreenState();
}

class _ClienteListScreenState extends State<ClienteListScreen> {
  final _ctrl = ClienteController();
  List<Cliente> _clientes = [];

  // Substitua com a forma correta de obter a empresa logada
  final int _idEmpresa = 1;

  Future<void> _load() async {
    _clientes = await _ctrl.listarPorEmpresa(_idEmpresa);
    setState(() {});
  }

  Future<void> _openForm([Cliente? c]) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ClienteFormScreen(cliente: c, idEmpresa: _idEmpresa),
      ),
    );
    if (result == true) _load();
  }

  void _confirmDelete(Cliente cliente) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Excluir Cliente'),
        content: Text('Deseja excluir ${cliente.nome}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () async {
              await _ctrl.excluirCliente(cliente.id!);
              Navigator.pop(ctx);
              _load();
            },
            child: const Text('Excluir', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext ctx) => Scaffold(
    appBar: AppBar(title: const Text('Clientes')),
    body: ListView.builder(
      itemCount: _clientes.length,
      itemBuilder: (_, i) => ListTile(
        title: Text(_clientes[i].nome),
        subtitle: Text(_clientes[i].telefone),
        trailing: IconButton(
          icon: const Icon(Icons.delete),
          onPressed: () => _confirmDelete(_clientes[i]),
        ),
        onTap: () => _openForm(_clientes[i]),
      ),
    ),
    floatingActionButton: FloatingActionButton(
      onPressed: () => _openForm(),
      child: const Icon(Icons.add),
    ),
  );
}
